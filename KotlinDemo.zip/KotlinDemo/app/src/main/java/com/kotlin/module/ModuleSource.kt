package com.kotlin.module

import android.content.Context

interface IModuleBean {
    fun getModuleName(): String
    fun onModuleClick(context: Context)
}

const val CAMERA_MODULE = 1
const val IMAGE_DECODER_MODULE = 2

class CameraModuleBean : IModuleBean {
    override fun getModuleName(): String = "Android Camera Demo"

    override fun onModuleClick(context: Context) {
        BaseFragmentActivity.innerIntent(context, CAMERA_MODULE)
    }
}

class ImageDecoderBean: IModuleBean {
    override fun getModuleName(): String = "Image Decoder"

    override fun onModuleClick(context: Context) {
        BaseFragmentActivity.innerIntent(context, IMAGE_DECODER_MODULE)
    }
}

object SourceList {
    fun getSourceList() = arrayOf(CameraModuleBean(), ImageDecoderBean())
}