package com.kotlin.module

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.kotlin.demo.R
import com.kotlin.module.camera.CameraFragment
import com.kotlin.module.image_decoder.ImageDecoderFragment

const val MODULE_BEAN = "Module_Bean"

class BaseFragmentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base_fragment)

        initFragment()
    }

    private fun initFragment() {
        val fragment = when (intent.getIntExtra(MODULE_BEAN, 0)) {
            CAMERA_MODULE -> CameraFragment()
            IMAGE_DECODER_MODULE -> ImageDecoderFragment()
            else -> DefaultFragment()
        }
        supportFragmentManager.beginTransaction().add(R.id.parent, fragment).commitAllowingStateLoss()
    }

    companion object {
        fun innerIntent(context: Context, module: Int) {
            BaseFragmentActivity().apply {
                val intent = Intent(context, this.javaClass)
                intent.putExtra(MODULE_BEAN, module)
                context.startActivity(intent)
            }
        }
    }
}
